# Plano de testes, <nome da iniciativa>

| Campo | Valor |
| --- | --- |
| Artefato | <ID e nome, por exemplo A01 Documento de visão> |
| Projeto ou produto | <nome> |
| Work item | <ID do Épico ou da Feature no Boards> |
| Categoria | <A, B, C, D ou E> |
| Autor | <nome e papel> |
| Revisor | <nome e papel> |
| Versão | <número> |
| Última revisão | <data> |
| Problema de origem | <P01 a P11, quando aplicável> |

## Estratégia
| Nível | O que verifica | Proporção automatizada | Quem executa |
| --- | --- | --- | --- |
| Unitário | | | DEV |
| Integração | | | DEV |
| Aceitação | | | QA |
| Exploratório | | Manual | QA |
| Segurança | <requisitos do A07> | | DEV e SEC |

## Escopo
O que será testado e o que foi deliberadamente deixado de fora.

## Ambientes e massa de dados
Como a massa é gerada e como o dado pessoal é anonimizado.

## Critérios de saída
| Critério | Valor exigido |
| --- | --- |
| Caminho principal coberto por teste automatizado | 100% dos itens |
| Defeito crítico em aberto | Nenhum |

## Riscos de teste
| Risco | Resposta |
| --- | --- |
