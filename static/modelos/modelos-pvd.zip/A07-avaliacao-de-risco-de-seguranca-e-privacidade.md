# Avaliação de risco, <nome da iniciativa>

| Campo | Valor |
| --- | --- |
| Artefato | <ID e nome, por exemplo A01 Documento de visão> |
| Projeto ou produto | <nome> |
| Work item | <ID do Épico ou da Feature no Boards> |
| Categoria | <A, B, C, D ou E> |
| Autor | <nome e papel> |
| Revisor | <nome e papel> |
| Versão | <número> |
| Última revisão | <data> |
| Problema de origem | <P01 a P11, quando aplicável> |

## Dados tratados
| Dado | Classificação | Base legal | Retenção |
| --- | --- | --- | --- |

## Superfície exposta
Interfaces, integrações e perfis de acesso.

## Riscos identificados
| Risco | Probabilidade | Impacto | Controle adotado | Responsável |
| --- | --- | --- | --- | --- |

## Requisitos de segurança aplicáveis
Nível ASVS exigido pela categoria: <1 ou 2>
| Requisito ASVS | Item de backlog |
| --- | --- |

## Parecer do encarregado de dados
Aprovado, aprovado com condições ou reprovado, com justificativa, nome e data.
