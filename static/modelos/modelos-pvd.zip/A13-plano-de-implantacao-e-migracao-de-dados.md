# Plano de implantação, <projeto> no cliente <nome>

| Campo | Valor |
| --- | --- |
| Artefato | <ID e nome, por exemplo A01 Documento de visão> |
| Projeto ou produto | <nome> |
| Work item | <ID do Épico ou da Feature no Boards> |
| Categoria | <A, B, C, D ou E> |
| Autor | <nome e papel> |
| Revisor | <nome e papel> |
| Versão | <número> |
| Última revisão | <data> |
| Problema de origem | <P01 a P11, quando aplicável> |

## Ambiente de destino
Infraestrutura do cliente, versões, acessos necessários e contato técnico da operadora.

## Pré-requisitos
| Pré-requisito | Responsável | Status |
| --- | --- | --- |

## Migração de dados
| Origem | Destino | Volume | Transformação | Validação |
| --- | --- | --- | --- | --- |

Ensaio em homologação realizado em <data>, com duração de <tempo>.

## Roteiro de implantação
| Passo | Ação | Responsável | Duração | Verificação |
| --- | --- | --- | --- | --- |

## Contingência
Gatilho para abortar, passos de reversão e como os dados voltam ao estado anterior.

## Treinamento
| Público | Conteúdo | Data | Material |
| --- | --- | --- | --- |

## Estabilização
Indicadores monitorados durante cinco dias úteis e valores esperados.
