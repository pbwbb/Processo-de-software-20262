# Modelagem de ameaças, <nome da iniciativa>

| Campo | Valor |
| --- | --- |
| Artefato | <ID e nome, por exemplo A01 Documento de visão> |
| Projeto ou produto | <nome> |
| Work item | <ID do Épico ou da Feature no Boards> |
| Categoria | <A, B, C, D ou E> |
| Autor | <nome e papel> |
| Revisor | <nome e papel> |
| Versão | <número> |
| Última revisão | <data> |
| Problema de origem | <P01 a P11, quando aplicável> |

## Escopo da modelagem
Componentes e fluxos de dados analisados, com referência ao diagrama do A06.

## Participantes
| Nome | Papel |
| --- | --- |

## Ameaças identificadas (STRIDE)
| ID | Componente | Categoria STRIDE | Ameaça | Probabilidade | Impacto | Contramedida | Item de backlog |
| --- | --- | --- | --- | --- | --- | --- | --- |
| T01 | | Spoofing | | | | | |

## Riscos aceitos
| ID | Justificativa | Aceito por (CTO) | Data |
| --- | --- | --- | --- |

## Revisão
Data prevista para revisar a modelagem, que deve ser refeita quando a arquitetura mudar.
