# Especificação de requisitos, <nome da iniciativa>

| Campo | Valor |
| --- | --- |
| Artefato | <ID e nome, por exemplo A01 Documento de visão> |
| Projeto ou produto | <nome> |
| Work item | <ID do Épico ou da Feature no Boards> |
| Categoria | <A, B, C, D ou E> |
| Autor | <nome e papel> |
| Revisor | <nome e papel> |
| Versão | <número> |
| Última revisão | <data> |
| Problema de origem | <P01 a P11, quando aplicável> |

## Contexto
Resumo do problema e referência ao A01.

## Atores
| Ator | Descrição | Perfil de acesso |
| --- | --- | --- |

## Requisitos funcionais do núcleo
### RF<NN> <nome>
- **Feature:** <ID no Boards>
- **Descrição:** <o que o sistema deve fazer>
- **Regras de negócio:** <RN<NN>, uma por linha>
- **Fluxo principal:** <passos numerados>
- **Fluxos de erro:** <passos numerados>
- **Critérios de aceite:** <Dado, quando, então>

## Regras de negócio
| ID | Regra | Fonte (contrato, norma ANS, TISS, LGPD) |
| --- | --- | --- |

## Requisitos não funcionais
| ID | Categoria | Requisito | Como será verificado |
| --- | --- | --- | --- |
| RNF01 | Desempenho | | |
| RNF02 | Segurança | <requisito ASVS selecionado na AT08> | |
| RNF03 | Privacidade | | |

## Integrações
| Sistema | Direção | Formato | Responsável do outro lado |
| --- | --- | --- | --- |

## Questões em aberto
| Questão | Responsável | Prazo |
| --- | --- | --- |
