**Como** <papel do usuário>
**quero** <capacidade>
**para que** <benefício>.

### Critérios de aceite
- Dado <contexto>, quando <ação>, então <resultado verificável>
- Dado <contexto>, quando <ação de erro>, então <tratamento esperado>

### Problema de origem
P<NN>

### Categoria
<A, B, C, D ou E>

### Dependências externas
- <sistema, equipe ou cliente de quem o item depende>
