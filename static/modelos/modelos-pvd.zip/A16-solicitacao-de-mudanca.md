# Solicitação de mudança <NNN>

**Solicitante**
**Data**
**Projeto**

## Mudança pedida
## Motivo
## Análise de impacto
| Dimensão | Impacto |
| --- | --- |
| Escopo | |
| Prazo | |
| Custo | |
| Risco | |

## Decisão
Aprovada, recusada ou aprovada com aditivo. Quem decidiu e quando.

## Linha de base atualizada
Referência à versão do escopo após a mudança.
