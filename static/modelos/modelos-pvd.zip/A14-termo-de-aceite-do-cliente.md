# Termo de aceite, <projeto>

| Campo | Valor |
| --- | --- |
| Artefato | <ID e nome, por exemplo A01 Documento de visão> |
| Projeto ou produto | <nome> |
| Work item | <ID do Épico ou da Feature no Boards> |
| Categoria | <A, B, C, D ou E> |
| Autor | <nome e papel> |
| Revisor | <nome e papel> |
| Versão | <número> |
| Última revisão | <data> |
| Problema de origem | <P01 a P11, quando aplicável> |

## Identificação
Contrato, cliente, período de execução.

## Entregas aceitas
| ID | Entrega | Referência da homologação |
| --- | --- | --- |

## Pendências aceitas
| Pendência | Prazo de resolução | Impacto no aceite |
| --- | --- | --- |

## Declaração
O cliente declara que as entregas acima atendem ao escopo contratado e ao registro de homologação, encerrando a fase de implantação. Correções posteriores seguem o contrato de sustentação.

## Assinaturas
| Parte | Nome | Cargo | Data |
| --- | --- | --- | --- |
| Vértice Sistemas | | Gerente de projeto | |
| Cliente | | | |
