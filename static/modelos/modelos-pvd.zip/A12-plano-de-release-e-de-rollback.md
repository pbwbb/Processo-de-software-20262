# Release <versão>

| Campo | Valor |
| --- | --- |
| Artefato | <ID e nome, por exemplo A01 Documento de visão> |
| Projeto ou produto | <nome> |
| Work item | <ID do Épico ou da Feature no Boards> |
| Categoria | <A, B, C, D ou E> |
| Autor | <nome e papel> |
| Revisor | <nome e papel> |
| Versão | <número> |
| Última revisão | <data> |
| Problema de origem | <P01 a P11, quando aplicável> |

## Conteúdo
| Item | Work item | Categoria |
| --- | --- | --- |

## Janela e comunicação
Data, duração estimada e quem é avisado, com antecedência.

## Sequência de implantação
1.

## Verificações pós-implantação
| Verificação | Resultado esperado | Responsável |
| --- | --- | --- |

## Plano de rollback
- **Gatilho de acionamento:** <condição objetiva, como taxa de erro acima de X% por Y minutos>
- **Passos:**
- **Tempo máximo de reversão:**
- **Testado em homologação em:** <data>
