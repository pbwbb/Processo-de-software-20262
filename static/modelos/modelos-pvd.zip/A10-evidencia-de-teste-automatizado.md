# Evidência de teste, release <versão>

| Campo | Valor |
| --- | --- |
| Artefato | <ID e nome, por exemplo A01 Documento de visão> |
| Projeto ou produto | <nome> |
| Work item | <ID do Épico ou da Feature no Boards> |
| Categoria | <A, B, C, D ou E> |
| Autor | <nome e papel> |
| Revisor | <nome e papel> |
| Versão | <número> |
| Última revisão | <data> |
| Problema de origem | <P01 a P11, quando aplicável> |

## Execução
| Campo | Valor |
| --- | --- |
| Pipeline e execução | <nome e número do run> |
| Commit | <hash> |
| Data | |
| Ambiente | Homologação |

## Resultado
| Suíte | Casos executados | Aprovados | Falhos | Cobertura de linhas |
| --- | --- | --- | --- | --- |
| Unitários | | | | |
| Integração | | | | |
| Aceitação | | | | |

## Análise estática e de dependências
| Ferramenta | Achados críticos | Achados altos | Portão de qualidade |
| --- | --- | --- | --- |
| SonarQube | | | Aprovado ou reprovado |
| Trivy | | | |

## Falhas e tratamento
| Caso | Defeito registrado | Decisão |
| --- | --- | --- |
