# Teste de intrusão, <aplicação e versão>

| Campo | Valor |
| --- | --- |
| Artefato | <ID e nome, por exemplo A01 Documento de visão> |
| Projeto ou produto | <nome> |
| Work item | <ID do Épico ou da Feature no Boards> |
| Categoria | <A, B, C, D ou E> |
| Autor | <nome e papel> |
| Revisor | <nome e papel> |
| Versão | <número> |
| Última revisão | <data> |
| Problema de origem | <P01 a P11, quando aplicável> |

## Escopo e regras de engajamento
Alvos, ambiente, janela, técnicas permitidas e excluídas.

## Metodologia
Referência usada, como OWASP Web Security Testing Guide, e nível ASVS verificado.

## Resumo executivo
| Severidade | Quantidade | Corrigidos antes do go-live |
| --- | --- | --- |
| Crítica | | |
| Alta | | |
| Média | | |
| Baixa | | |

## Achados
### V<NN> <título>
- **Severidade:** <crítica, alta, média ou baixa, com CVSS>
- **Componente afetado:**
- **Descrição e evidência:**
- **Recomendação:**
- **Item de backlog:**
- **Status:** aberto, corrigido ou risco aceito

## Conclusão
Liberado ou não liberado para produção, com nome e data.
