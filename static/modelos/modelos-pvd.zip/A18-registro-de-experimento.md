# Experimento, <título>

| Campo | Valor |
| --- | --- |
| Artefato | <ID e nome, por exemplo A01 Documento de visão> |
| Projeto ou produto | <nome> |
| Work item | <ID do Épico ou da Feature no Boards> |
| Categoria | <A, B, C, D ou E> |
| Autor | <nome e papel> |
| Revisor | <nome e papel> |
| Versão | <número> |
| Última revisão | <data> |
| Problema de origem | <P01 a P11, quando aplicável> |

## Hipótese
Acreditamos que <mudança técnica> resultará em <efeito>.

## Critério de sucesso
Métrica, valor que confirma a hipótese e como será medido.

## Prazo
Início, fim (máximo de quatro semanas).

## Execução
O que foi feito, repositório e ambiente usados.

## Resultado
Valor medido em comparação com o critério.

## Decisão
Seguir, com o ID da nova demanda na fila única, ou abandonar.

## Aprendizado
O que a equipe sabe agora que não sabia antes.
