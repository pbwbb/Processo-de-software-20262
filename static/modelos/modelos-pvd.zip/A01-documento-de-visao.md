# Visão, <nome da iniciativa>

| Campo | Valor |
| --- | --- |
| Artefato | <ID e nome, por exemplo A01 Documento de visão> |
| Projeto ou produto | <nome> |
| Work item | <ID do Épico ou da Feature no Boards> |
| Categoria | <A, B, C, D ou E> |
| Autor | <nome e papel> |
| Revisor | <nome e papel> |
| Versão | <número> |
| Última revisão | <data> |
| Problema de origem | <P01 a P11, quando aplicável> |

## Problema
Qual dor do cliente ou da operação motiva esta iniciativa, com a evidência que a sustenta.

## Oportunidade
O que a Vértice ganha ao resolver.

## Stakeholders
| Stakeholder | Interesse | Influência |
| --- | --- | --- |

## Escopo macro
### Incluído
- <capacidade, em uma frase>
### Excluído
- <o que deliberadamente fica de fora>

## Critérios de sucesso
| Métrica | Valor alvo | Prazo de verificação |
| --- | --- | --- |

## Riscos iniciais
Ver A15 Registro de riscos do projeto.

## Estimativa de ordem de grandeza
| Feature | Mínimo (pessoas-mês) | Máximo (pessoas-mês) |
| --- | --- | --- |
| Total | | |

Premissas usadas:
- <premissa>

## Categoria proposta
| Fator | Nível | Justificativa |
| --- | --- | --- |
| Sensibilidade do dado | | |
| Obrigação contratual | | |
| Exigência regulatória | | |
| Esforço estimado | | |
| Reversibilidade | | |

Categoria resultante: <A, B, C, D ou E>
