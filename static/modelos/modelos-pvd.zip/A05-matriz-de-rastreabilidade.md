| Requisito | Origem | Work item | Commit ou PR | Caso de teste | Status |
| --- | --- | --- | --- | --- | --- |
| RF01 | P02 / Feature 1234 | 1301 | PR 88 | TC 455 | Verificado |
