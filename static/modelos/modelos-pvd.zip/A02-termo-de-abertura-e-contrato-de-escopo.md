# Termo de abertura, <nome do projeto>

| Campo | Valor |
| --- | --- |
| Artefato | <ID e nome, por exemplo A01 Documento de visão> |
| Projeto ou produto | <nome> |
| Work item | <ID do Épico ou da Feature no Boards> |
| Categoria | <A, B, C, D ou E> |
| Autor | <nome e papel> |
| Revisor | <nome e papel> |
| Versão | <número> |
| Última revisão | <data> |
| Problema de origem | <P01 a P11, quando aplicável> |

## Cliente
Razão social, contato responsável e quem assina pelo cliente.

## Objetivo
O resultado de negócio esperado, em uma ou duas frases.

## Escopo contratado
| ID | Entrega | Critério de aceite resumido |
| --- | --- | --- |

## Fora do escopo
- <item explicitamente excluído>

## Premissas
- <condição que o cliente deve garantir, como acesso a ambiente ou dados>

## Restrições
- <prazo legal, janela de implantação, tecnologia imposta>

## Tolerância para mudança
Variação de escopo aprovada pelo GP sem aditivo, em horas ou percentual do contrato. Acima disso, vale o procedimento A16 com aditivo.

## Marcos
| Marco | Data prevista | Gate associado |
| --- | --- | --- |

## Aprovação
| Papel | Nome | Data |
| --- | --- | --- |
| Gerente de projeto | | |
| CTO | | |
| Cliente | | |
