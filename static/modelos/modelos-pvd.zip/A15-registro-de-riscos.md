| ID | Risco | Probabilidade | Impacto | Severidade | Resposta | Responsável | Status |
| --- | --- | --- | --- | --- | --- | --- | --- |
| R01 | | Baixa, média ou alta | Baixo, médio ou alto | Probabilidade x impacto | Evitar, mitigar, transferir ou aceitar | | Aberto |
