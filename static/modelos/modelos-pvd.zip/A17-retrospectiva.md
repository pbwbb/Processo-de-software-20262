# Retrospectiva, iteração <NN>

| O que funcionou | O que atrapalhou | Decisões | Ação de melhoria |
| --- | --- | --- | --- |

**Ação com responsável e prazo**
**Verificação da ação da iteração anterior** concluída, em andamento ou abandonada, e por quê
**Encaminhado ao engenheiro de processo** <sim ou não, e o quê>
