# ADR <NNN>, <título da decisão>

**Status** proposta, aceita ou substituída por ADR <NNN>
**Data**
**Decisores**

## Contexto
Situação técnica e restrições que forçaram a decisão.

## Decisão
O que foi decidido, em uma frase.

## Alternativas consideradas
| Alternativa | Vantagem | Por que foi descartada |
| --- | --- | --- |

## Consequências
O que passa a ser verdade, incluindo o custo aceito.
